'''
codes.py

author: sgkim
since: 2025-03-25
'''

from enum import IntEnum, _simple_enum

@_simple_enum(IntEnum)
class FileState:
    """ 
    FileState: IntEnum 
    """
    FAILED          = -2    # file is uploaded and processed but result of processing is failed.
    DELETED         = -1    # trash location, it should be removed by rule.
    UPLOADED        = 0     # file is uploaded. but is not start pro it should be removed after one day.
    PROCESSING      = 1     # file is uploaded and it is processing.
    COMPLETED       = 2     # file is uploaded and it completed processing.

@_simple_enum(IntEnum)
class SortDirection:
    """
    SortDirection: IntEnum
    """
    ASC             =  1    # order by col asc
    DESC            = -1    # order by col desc

@_simple_enum(IntEnum)
class UseYn:
    """
    UseYn
    """
    Y               =  1    # USE
    N               =  0    # NOT USE
