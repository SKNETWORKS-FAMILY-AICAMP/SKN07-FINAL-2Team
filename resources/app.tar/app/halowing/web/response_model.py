'''
rsponse_model.py

author: sgkim
since: 2025-03-25
'''
from datetime import datetime
from typing import List, Optional, Dict, Union, TypeVar, Generic
from pydantic import BaseModel, ConfigDict
from halowing.web.codes import SortDirection

class MessageResponseModel(BaseModel):
    '''
    Message type 응답 모델.
    '''
    success: bool = True
    messages: List[str]  = []

    model_config = ConfigDict(from_attributes=True, )

T = TypeVar('T')

class SearchResponseModel(Generic[T], BaseModel):
    '''
    SearchResponseModel
    '''
    datas: List[T]         = []
    condition: Optional[Dict[str, Union[str,int]]]  = None
    sort: Optional[Dict[str,SortDirection]] = None
    offset: int                             = 0
    limit: int                              = 10
    total: int                              = 0

    # model_config = ConfigDict(from_attributes=True )
    model_config = {
        "title": "SearchResponseModel",
        "from_attributes": True,  # orm_mode는 from_attributes로 변경되었습니다.
        "arbitrary_types_allowed": True,
        "populate_by_name": True, # allow_population_by_field_name 은 populate_by_name 으로 변경되었습니다.
        "use_enum_values": True,
        "json_encoders": {
            datetime: lambda v: v.strftime("%Y-%m-%d %H:%M:%S"),
        },
    }
    # class Config:
    #     ''' Config '''
    #     title = "SearchResponseModel"
    #     orm_mode = True
    #     arbitrary_types_allowed = True
    #     allow_population_by_field_name = True
    #     use_enum_values = True
    #     json_encoders = {
    #         datetime: lambda v: v.strftime("%Y-%m-%d %H:%M:%S"),
    #     }
