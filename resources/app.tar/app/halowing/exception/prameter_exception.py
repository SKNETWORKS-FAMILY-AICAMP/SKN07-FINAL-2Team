'''
package: halowing.exception
module : prameter_exception.py
'''
class NullParameterError(ValueError):
    '''
    If Input parameter is None then raise NullParameterError.
    '''

    def __init__(self, param_name:str):
        super().__init__(f"파라미터 '{param_name}'은/는 Null일 수 없습니다.")



