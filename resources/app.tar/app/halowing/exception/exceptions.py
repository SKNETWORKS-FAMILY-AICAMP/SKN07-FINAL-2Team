'''
package: halowing.exception
module : http_exception.py

author: sgkim
since: 2025-03-24
'''
class CustomBaseException(Exception):
   ''' 사용자 Exception '''
   def __init__(self, reqeust_data:str, message:str):
        self.request_data = reqeust_data
        super().__init__(message)

class NotFoundException(CustomBaseException):
    '''
    requested data not found error.
    '''
    def __init__(self, reqeust_data:str):
        super().__init__(reqeust_data, f"요청하는 값을 찾을 수 없습니다. 요청 값 = {reqeust_data}")

class DeleteNotPermissionedError(Exception):
    ''' 삭제 할 수 없는 파일에 대한 삭제 요청 처리 '''
    def __init__(self, file_name:str):
        super().__init__(file_name ,f"삭제 할 수 없는 파일에 대한 삭제 요청 처리 = {file_name}")
