'''
validators.py
validate input parameter of function

author: sgkim
since: 2025-03-24
'''
import inspect

from halowing.exception.prameter_exception import NullParameterError

def check_null_params(func):
    """Null 파라미터 체크 데코레이터"""
    def wrapper(*args, **kwargs):
        sig = inspect.signature(func)
        bound_args = sig.bind(*args, **kwargs)
        bound_args.apply_defaults()

        for name, value in bound_args.arguments.items():
            if value is None:
                raise NullParameterError(name)
        return func(*args, **kwargs)
    return wrapper