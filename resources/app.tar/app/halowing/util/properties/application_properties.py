'''
application_properties.py

author: sgkim
since : 2025-03-19
'''
import threading
import logging
from typing import Optional, Any
import importlib.resources as pkg_resources
import yaml

class ApplicationProperties:
    '''
    Application propeties
    /meta/application.yml 파일을 이용하여 application에서 사용할 환경 변수를 제공한다.
    '''
    _instance = None
    _lock = threading.Lock()
    _log = logging.getLogger()

    _package_name = 'meta'
    _resource_name = 'application.yml'

    def __new__(cls, package_name:Optional[str]=None, resource_name:Optional[str]=None):
        cls._log.debug('start init properties: %s',cls._package_name)
        if cls._instance:
            return cls._instance
        
        with cls._lock:
            if cls._instance:
                return cls._instance

            if package_name is not None:
                cls._package_name = package_name
            
            if resource_name is not None:
                cls._resource_name = resource_name

            cls._instance = super(ApplicationProperties, cls).__new__(cls)

            try:
                yaml_string = pkg_resources.read_text(cls._package_name, cls._resource_name)

                cls._log.debug('yaml_string= \n%s\n', yaml_string)

                cls.properties = yaml.safe_load(yaml_string)
            except FileNotFoundError:
                cls._log.error("오류: %s 파일을 찾을 수 없습니다.",cls._resource_name)
                return None
            except yaml.YAMLError as e:
                cls._log.error("오류: YAML 파일 파싱 중 오류 발생: %s",e)
                return None
            except Exception as e:
                cls._log.error("오류: 알 수 없는 오류 발생: %s", e)
                return None
            
            return cls._instance
    
    def get(self, key:str, default_value:Optional[str]=None):
        '''
        get application.yml 에서 key에 해당하는 value를 반환한다.

        key:str         key 값
        default_value:str  값이 없을 때 반환할 default 값값
        '''
        _value = self[key]
        
        return _value if _value is not None else default_value
    
    def __simple_getitem__(self, key:str):
        '''
        simple parsing yaml file.

        :param key: str
        '''
        _value = self.properties
        for _step in key.split('.'):
            _value = _value[_step]
        return _value

    def __getitem__(self, key:str) -> Any:
        return self.__simple_getitem__(key)
    
    def __str__(self):
        return self.properties.__str__()
