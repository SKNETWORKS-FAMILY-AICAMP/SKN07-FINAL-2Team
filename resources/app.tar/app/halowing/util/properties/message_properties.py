'''
response_message.py
'''
import re
import threading
import logging
from typing import Optional, Any
import importlib.resources as pkg_resources
import yaml

class ResponseMessage:
    '''
    응답 메시지.
    '''
    _instance = None
    _lock = threading.Lock()
    _log = logging.getLogger('ResponseMessage')

    _package_name = 'meta.response'
    _resource_name = 'messages.yml'

    def __new__(cls, package_name:Optional[str]=None, resource_name:Optional[str]=None):
        cls._log.debug('start init properties: %s',cls._package_name)
        if cls._instance:
            return cls._instance
        
        with cls._lock:
            if cls._instance:
                return cls._instance

            if package_name is not None:
                cls._package_name = package_name
            
            if resource_name is not None:
                cls._resource_name = resource_name

            cls._instance = super(ResponseMessage, cls).__new__(cls)

            try:
                yaml_string = pkg_resources.read_text(cls._package_name, cls._resource_name)

                # cls._log.debug('yaml_string= \n%s\n', yaml_string)

                cls.properties = yaml.safe_load(yaml_string)
            except FileNotFoundError:
                cls._log.error("오류: %s 파일을 찾을 수 없습니다.",cls._resource_name)
                return None
            except yaml.YAMLError as e:
                cls._log.error("오류: YAML 파일 파싱 중 오류 발생: %s",e)
                return None
            except Exception as e:
                cls._log.error("오류: 알 수 없는 오류 발생: %s", e)
                return None
            
            return cls._instance

    def get(self, key:str, default_value:Optional[str]=None):
        '''
        get application.yml 에서 key에 해당하는 value를 반환한다.

        key:str         key 값
        default_value:str  값이 없을 때 반환할 default 값
        '''
        _value = self[key]
        
        return _value if _value is not None else default_value
    
    def __simple_getitem__(self, key:str) -> str:
        '''
        simple parsing yaml file.

        :param key: str
        '''
        _value = None
        try:
            _value = self.properties
            for _step in key.split('.'):
                _value = _value[_step]
        except Exception as ex:
            self._log.error(f'Error - {ex}')
            _value = None
        return _value if _value else key

    def __replace_by_properties(self, _message:str) -> str:
        '''
        문자열 대체
        '''
        _tmp = re.findall(r'\{([^}]+)\}', _message)
        if _tmp is None or len(_tmp) == 0:
            return _message
        
        def replace(match):
            key = match.group(1)
            return self.__simple_getitem__(key)  # 키가 없으면 원래 형태 유지
        _rs = re.sub(r'\{([^}]+)\}', replace, _message)
        return self.__replace_by_properties(_rs)

    def __getitem__(self, key:str) -> Any:
        self._log.debug('key= %s',key)
        _rs = self.__simple_getitem__(key)
        self._log.debug('_rs= %s',_rs)
        _rs= self.__replace_by_properties(_rs)
        return _rs
    
    def __str__(self):
        return self.properties.__str__()
