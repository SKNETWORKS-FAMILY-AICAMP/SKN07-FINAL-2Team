'''
이 모듈은 파일 저장 관련 유틸리티입니다.
'''
import os
import logging
from lib.halowing.exception.prameter_exception import check_null_params


class FileUtil:
    '''
    FileUtil
    '''
    _log = logging.getLogger('FileUtil')

    @classmethod
    def save(cls, file_name:str, obj):
        '''
        it save binary file.
        '''
        FileUtil.__create_path(file_name)
        rs = 0
        with open(file_name, 'wb') as f:
            f.write(obj)
        return rs
    
    @classmethod
    def write(cls, file_name:str, text:str, is_append:bool=False, encoding:str = 'utf-8'):
        '''
        it save text file.
        '''
        FileUtil.__create_path(file_name)
        rs = 0
        with open(file_name, 'a' if is_append else 'w' , encoding=encoding,) as f:
            rs = f.write(text)
        return rs

    @classmethod
    @check_null_params
    def __create_path(cls, file_name:str):
        '''
        it create path for saving file. 
        '''
        # if file_name is None:
        #     raise Exception("parameter error [file_name].")
        abs_path = os.path.abspath(file_name)
        __root = os.sep.join(abs_path.split(os.sep)[:-1])
        cls._log.debug(f'root directory = {__root}')
        os.makedirs(__root,exist_ok=True)

if '__main__' == __name__:
    FileUtil.write('/temp/Readme.txt','hello world')
