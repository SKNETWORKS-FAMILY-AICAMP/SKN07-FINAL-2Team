'''
halowing.util.io.file.file_storage
'''
import os

class FileStorage:
    '''
    class FileStorage
    '''

    def __init__(self, storage_home:str=None):
        '''
        init 
        '''
        if storage_home is None:
            self.storage_home = os.path.abspath('storage')
        else:
            self.storage_home = os.path.abspath(storage_home)

    def save(self, file_name:str):
        '''
        save file to storage
        '''
